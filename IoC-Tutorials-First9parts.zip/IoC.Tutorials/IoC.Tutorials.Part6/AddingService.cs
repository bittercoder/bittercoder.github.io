using Castle.Core;

namespace IoC.Tutorials.Part6
{
    [Transient]
    public class AddingService
    {
        private int _total = 0;

        public void AddAmmount(int ammount)
        {
            _total += ammount;
        }

        public int Total
        {
            get { return _total; }
        }
    }
}