namespace IoC.Tutorials.Part5
{
    public class WhatConfigurationService
    {
        private string _configuration;

        public string Configuration
        {
            get { return _configuration; }
            set { _configuration = value; }
        }
    }
}