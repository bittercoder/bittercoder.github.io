using System.IO;

namespace IoC.Tutorials.Part8
{
    public class FileReader
    {
        private string _fileName;

        public string FileName
        {
            get { return _fileName; }
            set { _fileName = value; }
        }

        public string ReadToEnd()
        {
            return File.ReadAllText(_fileName);
        }
    }
}