namespace IoC.Tutorials.Part4
{
    public class WhatConfigurationService
    {
        private string _configuration;

        public string Configuration
        {
            get { return _configuration; }
            set { _configuration = value; }
        }
    }
}