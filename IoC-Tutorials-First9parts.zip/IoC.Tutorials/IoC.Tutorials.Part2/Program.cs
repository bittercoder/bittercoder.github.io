using System;
using Castle.Windsor;
using Castle.Windsor.Configuration.Interpreters;

namespace IoC.Tutorials.Part2
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            WindsorContainer container = new WindsorContainer(new XmlInterpreter());

            HolidayService holidayService = container.Resolve<HolidayService>();

            DateTime xmas = new DateTime(2007, 12, 25);
            DateTime newYears = new DateTime(2008, 1, 1);

            if (holidayService.IsHoliday(xmas))
                Console.WriteLine("merry xmas!");
            else
                Console.WriteLine("xmas is only for management!");

            if (holidayService.IsHoliday(newYears))
                Console.WriteLine("happy new year");
            else
                Console.WriteLine("new year, you haven't done all the work for last year!");

            Console.Read();
        }
    }
}