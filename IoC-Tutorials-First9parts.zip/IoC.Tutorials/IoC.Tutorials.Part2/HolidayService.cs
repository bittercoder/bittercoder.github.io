using System;

namespace IoC.Tutorials.Part2
{
    public class HolidayService
    {
        private DateTime[] _holidays;

        public DateTime[] Holidays
        {
            get { return _holidays; }
            set { _holidays = value; }
        }

        public bool IsHoliday(DateTime date)
        {
            if (_holidays != null)
            {
                DateTime matchDate = date.Date;
                foreach (DateTime test in Holidays)
                {
                    if (test.Date.Equals(matchDate))
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}