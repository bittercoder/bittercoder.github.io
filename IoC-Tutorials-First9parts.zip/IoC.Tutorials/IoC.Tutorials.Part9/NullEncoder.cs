namespace IoC.Tutorials.Part9
{
    public class NullEncoder : IEncoder
    {
        public string Encode(string source)
        {
            return source;
        }
    }
}