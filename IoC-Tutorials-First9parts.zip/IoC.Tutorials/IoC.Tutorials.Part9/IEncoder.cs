namespace IoC.Tutorials.Part9
{
    public interface IEncoder
    {
        string Encode(string source);
    }
}