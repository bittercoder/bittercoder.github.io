using System;
using Castle.Windsor;
using Castle.Windsor.Configuration.Interpreters;

namespace IoC.Tutorials.Part9
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            WindsorContainer container = new WindsorContainer(new XmlInterpreter());

            SecretMessageSender sender = container.Resolve<SecretMessageSender>();

            sender.SendMessage("hammet", "castle is great!");

            Console.Read();
        }
    }
}