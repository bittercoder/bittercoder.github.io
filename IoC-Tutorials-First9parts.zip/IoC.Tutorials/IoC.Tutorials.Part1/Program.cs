using System;
using Castle.Windsor;
using Castle.Windsor.Configuration.Interpreters;

namespace IoC.Tutorials.Part1
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            WindsorContainer container = new WindsorContainer(new XmlInterpreter());

            TaxCalculator calculator = container.Resolve<TaxCalculator>();

            decimal gross = 100;
            decimal tax = calculator.CalculateTax(gross);

            Console.WriteLine("Gross: {0}, Tax: {1}", gross, tax);
            Console.Read();
        }
    }
}