using System;
using Castle.Windsor;
using Castle.Windsor.Configuration.Interpreters;

namespace IoC.Tutorials.Part7
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            WindsorContainer container = new WindsorContainer(new XmlInterpreter());

            IMessageOfTheDay motd = container.Resolve<IMessageOfTheDay>();

            Console.WriteLine("MOTD: {0}", motd.GetMessageOfTheDay());

            Console.Read();
        }
    }
}