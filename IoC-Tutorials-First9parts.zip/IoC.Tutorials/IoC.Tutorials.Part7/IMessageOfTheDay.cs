namespace IoC.Tutorials.Part7
{
    public interface IMessageOfTheDay
    {
        string GetMessageOfTheDay();
    }
}