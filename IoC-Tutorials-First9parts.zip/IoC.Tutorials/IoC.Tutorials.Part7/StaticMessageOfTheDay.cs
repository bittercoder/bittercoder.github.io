namespace IoC.Tutorials.Part7
{
    public class StaticMessageOfTheDay : IMessageOfTheDay
    {
        private string _message;

        public string Message
        {
            set { _message = value; }
        }

        public string GetMessageOfTheDay()
        {
            return _message;
        }
    }
}