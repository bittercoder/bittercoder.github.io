using System.Net;

namespace IoC.Tutorials.Part7
{
    public class WikiQuotesMessageOfTheDay : IMessageOfTheDay
    {
        public string GetMessageOfTheDay()
        {
            WebClient client = new WebClient();
            string content = client.DownloadString("http://en.wikiquote.org/wiki/Main_Page");

            string toFind = "<div style=\"background: #fff5f5\">";
            int start = content.IndexOf(toFind) + toFind.Length;
            int length = content.IndexOf("<a", start) - start;

            return content.Substring(start, length);
        }
    }
}