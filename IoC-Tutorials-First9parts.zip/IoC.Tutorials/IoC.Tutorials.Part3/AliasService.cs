using System.Collections.Generic;

namespace IoC.Tutorials.Part3
{
    public class AliasService
    {
        private Dictionary<string, string> _aliases;

        public Dictionary<string, string> Aliases
        {
            get { return _aliases; }
            set { _aliases = value; }
        }

        public string Evaluate(string term)
        {
            if (_aliases == null) return term;

            while (_aliases.ContainsKey(term))
            {
                term = _aliases[term];
            }

            return term;
        }
    }
}